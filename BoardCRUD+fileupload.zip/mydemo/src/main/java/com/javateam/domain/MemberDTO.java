package com.javateam.domain;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class MemberDTO {
	
	private int no;
	private String name;
	private String title;
	private String content;
	private String password;
	private MultipartFile file;
	private Date date;

}
