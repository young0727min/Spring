package com.javateam.domain;

import lombok.Data;

@Data
public class FileVO {
	private String fileName;
	private String msg;
}
