package com.javateam.domain;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MemberVO{
	
	private int no;
	@NotNull
	@Size(min=2,max=15, message="이름은 2~15자 입니다")
	private String name;
	@NotNull
	@Size(min=2,max=15, message="제목은 2~15자 입니다")
	private String title;
	@NotNull
	@Size(min=2,max=1000, message="내용은 2~1000자 입니다")
	private String content;
	@NotNull
	private String password;
	private String file;
	private Date date;
	
	//MemberDTO --> MemberVO
public MemberVO(MemberDTO member) {
	
	this.no = member.getNo();
	this.name = member.getName();
	this.title = member.getTitle();
	this.content = member.getContent();
	this.password = member.getPassword();
	this.file = member.getFile().getOriginalFilename(); //파일명 저장
	this.date = member.getDate();
}
	
	
}
