package com.javateam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.javateam.domain.MemberVO;
import com.javateam.service.MemberService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class BoardViewController {
	
	@Autowired
	private MemberService service;
	
	// JSON Feed Service : 개별 게시글 보기
	@RequestMapping(value="/boardDetailREST.do/{no}",
					produces="application/json; charset=UTF-8")
	public ResponseEntity<String> boardDetailFeed(@PathVariable("no") int no) throws Exception
	{
		log.info("##### boardDetailREST.do #####");
		
		// HTTP Header 정보 setting
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Content-Type", "application/json; charset=UTF-8");
		

		String json="";
		ObjectMapper mapper = new ObjectMapper();
		MemberVO member = service.read(no);
		
		// 첨부 파일명 원래 파일명으로 변경 처리 : 마지막 첨가되었던 접미사("_게시글 아이디") 제거
		if (member.getFile() != null) {
			
			// "_게시글 아이디" -> 공백 (치환)
			String fileName = member.getFile().replaceAll("_"+member.getNo(), "");
			member.setFile(fileName);
			
			log.info("### 원래 파일 명 : {}", member.getFile());
		} // 
	       
        try {
               json = mapper.writeValueAsString(member);
                
        } catch (JsonProcessingException e) {
            log.error("json exception !");
            e.printStackTrace();
        }
		
        return new ResponseEntity<String>(json, responseHeaders, HttpStatus.OK);
	} //
	
}