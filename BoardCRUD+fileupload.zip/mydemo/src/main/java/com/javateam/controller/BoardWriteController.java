package com.javateam.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.javateam.domain.FileVO;
import com.javateam.domain.MemberDTO;
import com.javateam.domain.MemberVO;
import com.javateam.service.FileUploadService;
import com.javateam.service.MemberService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class BoardWriteController {
	
	@Autowired
	private FileUploadService fileUploadService; //업로드 파일 처리
	
	@Autowired
	private MemberService service;
	
	@RequestMapping(value="/write.do")
	public String writeForm(Model model)throws Exception {
		
		log.info("******************************** writeForm ********************************");
		
		model.addAttribute("MemberVO",new MemberVO());
		
		return "write";
	}
	
	
	@RequestMapping(value="/writeProcREST.do",method=RequestMethod.POST,produces="text/plain; charset=UTF-8")
	@ResponseBody
	public String writeProc(@ModelAttribute("MemberDTO")MemberDTO memberDTO,
			@RequestParam(value="file",required=false)MultipartFile file) {
		
		log.info("******************************* writeFlagMsg **************************");
		log.info("VO :{}",memberDTO);
		
		boolean flag = false; //글쓰기 성공여부 플래그 추가
		String msg = "";
		int no = 0;
		//신규 NO(게시판 번호) 값 구하기
		no = service.getMemberNoByLastSeq();
		log.info("게시글 번호:"+no);
		
		//첨부 파일 처리
		FileVO fileVO = fileUploadService.storeUploadFile(no,file);
		
		//저장 VO 생성
		MemberVO memberVO = new MemberVO(memberDTO);
		memberVO.setFile(!file.isEmpty()&& file != null?fileVO.getFileName():"");
		
		memberVO.setNo(no);
		log.info("memberVO :{}"+memberVO);
		
		flag = service.write(memberVO);
		
		if(flag == false) {
			msg += "글쓰기에 실패하였습니다";
		}else {
			msg += "글쓰기에 성공하였습니다";
		}
		return msg;
	}
	
	
	
	
	@RequestMapping(value="/writeProc.do",method=RequestMethod.POST)
	public String writeProc(@ModelAttribute("MemberDTO")MemberDTO memberDTO) {
		
		log.info( "******************************** writeFile ********************************");
		log.info("memberDTO:"+memberDTO);
		
		MultipartFile file = memberDTO.getFile(); //업로드 파일
		
		//신규 게시판 번호 값 구하기
		int no = 0;
		no = service.getMemberNoByLastSeq(); //신규 NO(게시판 번호) 값 구하기
		
		log.info("시퀀스 게시글 번호:" + no);
		
		//첨부 파일 처리
		FileVO fileVO = fileUploadService.storeUploadFile(no, file); 
		
		log.info("첨부 파일 처리:"+fileVO.getMsg());
		
		MemberVO memberVO = new MemberVO(memberDTO);
		//유효성 검사
		memberVO.setFile(!memberDTO.getFile().isEmpty()&&file!=null?fileVO.getFileName():"");
		
		memberVO.setNo(no);
		log.info("memberVO: {}",memberVO);
		
		service.write(memberVO);
		
		return "redirect:/list";
		
	}

}
