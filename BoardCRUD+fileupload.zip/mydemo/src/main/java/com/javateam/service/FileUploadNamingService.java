package com.javateam.service;

public interface FileUploadNamingService {
	
	String parseFilePostfix(int no,String destFile);
	String getOriginalFilename(int no,String fileName);
}
