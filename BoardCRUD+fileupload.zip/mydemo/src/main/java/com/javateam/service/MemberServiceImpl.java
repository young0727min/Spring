package com.javateam.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.javateam.dao.MemberDAO;
import com.javateam.domain.MemberVO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MemberServiceImpl implements MemberService {
	
	@Inject
	private MemberDAO dao;
	
	private boolean flag = false;

	@Override
	public int getMemberNoByLastSeq() {
		
		log.info("Service getMemberNoByLastSeq");
		
		
		return dao.getMemberNoByLastSeq();
	}


	@Override
	public List<MemberVO> list()throws Exception {
		// TODO Auto-generated method stub
		return dao.list();
	}


	@Override
	public MemberVO read(int no)throws Exception {
		// TODO Auto-generated method stub
		return dao.select(no);
	}


	@Override
	public boolean write(MemberVO memberVO) {
		
		log.info("Service write");
		
		try {
			flag = dao.insert(memberVO);
			if(flag == false)throw new Exception();
		}catch(Exception e) {
			flag = false;
			log.debug("Service write Exception :" + e.getMessage());
		}
		return flag;
	}


	@Override
	public void edit(MemberVO memberVO) throws Exception{
		// TODO Auto-generated method stub
		 dao.update(memberVO);
	}


	@Override
	public int delete(MemberVO memberVO) throws Exception {
		// TODO Auto-generated method stub
	   return dao.delete(memberVO);
	}
	
	
	
	
	

}
