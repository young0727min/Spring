package com.javateam.service;

import org.springframework.web.multipart.MultipartFile;

import com.javateam.domain.FileVO;


public interface FileUploadService {
	
	FileVO storeUploadFile(int no,MultipartFile file);
}
