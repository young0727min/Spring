package com.javateam.mapper;

import com.javateam.domain.MemberVO;

public interface MemberMapper {
	
	void insert(MemberVO memberVO);
	int getMemberNoByLastSeq(); //게시글 마지막 번호 리턴 메서드
	
}
